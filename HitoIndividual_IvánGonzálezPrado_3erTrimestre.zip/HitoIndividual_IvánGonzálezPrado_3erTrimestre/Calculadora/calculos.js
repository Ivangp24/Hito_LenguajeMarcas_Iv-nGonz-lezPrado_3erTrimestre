let display = document.getElementById('display');

function appendToDisplay(value) {
  display.value += value;
}

function clearDisplay() {
  display.value = '';
}

function backspace() {
  display.value = display.value.slice(0, -1);
}

function calculate(operation) {
  let currentValue = display.value;

  if (currentValue.endsWith('+') || currentValue.endsWith('-') || currentValue.endsWith('*') || currentValue.endsWith('/')) {
    display.value = currentValue.slice(0, -1) + operation;
  } else {
    display.value += operation;
  }
}

function calculateResult() {
  let result = eval(display.value);
  display.value = result;
}

function calculateSquare() {
  let currentValue = display.value;
  let square = eval(currentValue) ** 2;
  display.value = square;
}

function calculateSquareRoot() {
  let currentValue = display.value;
  let squareRoot = Math.sqrt(eval(currentValue));
  display.value = squareRoot;
}

function calculatePercentage() {
  let expression = display.value;
  let percentage = eval(expression) / 100;
  display.value = percentage;
}