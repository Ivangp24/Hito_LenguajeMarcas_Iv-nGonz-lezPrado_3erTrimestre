    // Realiza la petición fetch al API REST
    fetch('https://www.el-tiempo.net/api/json/v1/provincias')
      .then(response => response.json())
      .then(data => {
        const provincesTableBody = document.getElementById('provinces-table-body');

        // Recorre los datos y generar filas en la tabla
        data.forEach(province => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${province.CODPROV}</td>
            <td>${province.NOMBRE_PROVINCIA}</td>
            <td>${province.CODAUTON}</td>
            <td>${province.COMUNIDAD_CIUDAD_AUTONOMA}</td>
            <td>${province.CAPITAL_PROVINCIA}</td>
          `;
          provincesTableBody.appendChild(row);
        });
      })
      .catch(error => console.log(error));